#!/usr/bin/env python3
"""
Autotile Fidoria (iso 128x64) -- logika dibuat sependek & sejelas mungkin.

KONSEP (3 langkah):
  1. Terrain disimpan di VERTEX (titik sudut grid), ukuran (W+1) x (H+1).
  2. Sel (x,y) punya 4 sudut:   NW=(x,y)  NE=(x+1,y)  SE=(x+1,y+1)  SW=(x,y+1)
  3. Tile dipilih dari 4 sudut itu:
        mask = NW*1 + NE*2 + SE*4 + SW*8      (bit 1 = terrain kedua di nama pair)

Contoh:  grass_water -> bit 0 = grass, bit 1 = water
         sudut [NW,NE,SE,SW] = [grass,grass,water,water] -> mask 0+0+4+8 = 12
         -> tabel pair grass_water mask 12 -> edge_grassN  (grass di sisi N)

Pakai:
    from autotile import Autotiler
    at = Autotiler()                       # baca autotile_rules.json
    tile = at.pick("grass","grass","water","water", x=3, y=7)
    print(tile.name, tile.path, tile.mask)
Demo:  python3 autotile.py demo
"""
import json, os, sys, zlib

HERE = os.path.dirname(os.path.abspath(__file__))
BIT = {"NW": 1, "NE": 2, "SE": 4, "SW": 8}


class Pick:
    """Hasil pilihan satu sel."""
    def __init__(self, path, name, mask, pair=None, note=""):
        self.path, self.name, self.mask, self.pair, self.note = path, name, mask, pair, note

    def __repr__(self):
        return f"Pick({self.name!r}, mask={self.mask}, pair={self.pair}, path={self.path}{', ' + self.note if self.note else ''})"


class Autotiler:
    def __init__(self, rules_path=None):
        self.rules = json.load(open(rules_path or os.path.join(HERE, "autotile_rules.json")))
        self.priority = self.rules["terrain_priority"]          # grass > dirt > sand > water
        # lookup cepat: frozenset({a,b}) -> nama pair
        self.pair_of = {frozenset(p.split("_")): p for p in self.rules["pairs"]}
        self.problems = []                                      # sel yang tidak valid dicatat di sini

    # ---- tile polos (1 terrain) -------------------------------------------------
    def base(self, terrain, x, y):
        variants = self.rules["base"][terrain]
        i = zlib.crc32(f"{x},{y}".encode()) % len(variants)     # variasi stabil per sel
        return Pick(variants[i], f"pure_{terrain}", -1, None)

    # ---- fungsi utama -----------------------------------------------------------
    def pick(self, nw, ne, se, sw, x=0, y=0):
        corners = {"NW": nw, "NE": ne, "SE": se, "SW": sw}
        kinds = set(corners.values())

        # kasus 1: keempat sudut sama -> tile polos
        if len(kinds) == 1:
            return self.base(nw, x, y)

        # kasus 2: dua terrain -> cari pair-nya
        pair = self.pair_of.get(frozenset(kinds)) if len(kinds) == 2 else None
        if pair is None:
            self.problems.append((x, y, sorted(kinds)))         # 3 terrain / pair tak ada (mis. dirt-water)
            return Pick(None, "INVALID", -1, None, f"terrain {sorted(kinds)} tidak punya transisi")

        t2 = self.rules["pairs"][pair]["T2"]
        mask = sum(BIT[c] for c, t in corners.items() if t == t2)

        # kasus 3: saddle (diagonal) tidak punya tile -> turunkan ke terrain prioritas tertinggi
        if mask in self.rules["saddle_masks"]:
            self.problems.append((x, y, f"saddle {pair}"))
            top = min(kinds, key=self.priority.index)
            p = self.base(top, x, y); p.note = "saddle->polos"; return p

        entry = self.rules["pairs"][pair]["masks"][str(mask)]
        return Pick(entry["tile"] or self.base(entry["corners"]["NW"], x, y).path, entry["name"], mask, pair)

    # ---- helper peta -------------------------------------------------------------
    def from_vertices(self, V):
        """V[y][x] = terrain di vertex. Return grid Pick ukuran (H x W), H=len(V)-1."""
        H, W = len(V) - 1, len(V[0]) - 1
        return [[self.pick(V[y][x], V[y][x + 1], V[y + 1][x + 1], V[y + 1][x], x, y)
                 for x in range(W)] for y in range(H)]

    def from_cells(self, C):
        """Kalau kamu melukis per SEL (bukan vertex): C[y][x] = terrain sel.
        Pakai dual-grid: tile digambar di vertex, mengambil 4 sel di sekelilingnya.
        Hasil ukuran (H+1)x(W+1); gambar digeser setengah sel: grid (-0.5,-0.5)."""
        H, W = len(C), len(C[0])
        g = lambda x, y: C[min(max(y, 0), H - 1)][min(max(x, 0), W - 1)]
        return [[self.pick(g(x - 1, y - 1), g(x, y - 1), g(x, y), g(x - 1, y), x, y)
                 for x in range(W + 1)] for y in range(H + 1)]


def to_screen(x, y, w=128, h=64):
    return (x - y) * w // 2, (x + y) * h // 2


def render(grid, out, root=HERE, bg=(40, 40, 48, 255)):
    from PIL import Image
    H, W = len(grid), len(grid[0])
    cv = Image.new("RGBA", ((W + H) * 64, (W + H) * 32 + 64), bg)
    ox = H * 64
    cache = {}
    for y in range(H):
        for x in range(W):
            p = grid[y][x]
            if not p.path:
                continue
            im = cache.setdefault(p.path, Image.open(os.path.join(root, p.path)).convert("RGBA"))
            sx, sy = to_screen(x, y)
            cv.alpha_composite(im, (ox + sx, sy))
    cv.save(out)


def demo():
    import math
    N = 28
    V = [["grass"] * N for _ in range(N)]
    for y in range(N):
        for x in range(N):
            d = math.hypot(x - 11, y - 11)
            if d < 4.6: V[y][x] = "water"
            elif d < 7.2: V[y][x] = "sand"
            d2 = math.hypot(x - 22, y - 5)
            if d2 < 3.0: V[y][x] = "dirt"
            d4 = math.hypot(x - 4, y - 23)             # plaza cobble di rumput
            if d4 < 4.2: V[y][x] = "cobble"
            d3 = math.hypot(x - 21, y - 21)            # kolam kecil: air > pasir > tanah > rumput
            if d3 < 5.2: V[y][x] = "dirt"
            if d3 < 3.4: V[y][x] = "sand"
            if d3 < 1.7: V[y][x] = "water"
    at = Autotiler()
    grid = at.from_vertices(V)
    render(grid, os.path.join(HERE, "previews", "autotile_demo.png"))
    print("sel bermasalah:", at.problems or "tidak ada")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "demo":
        os.makedirs(os.path.join(HERE, "previews"), exist_ok=True)
        demo()
    else:
        print(__doc__)
