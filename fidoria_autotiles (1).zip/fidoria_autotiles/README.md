# Fidoria Autotiles (iso 128x64)

## Logika dalam 1 rumus
Terrain disimpan di **sudut (vertex)** grid. Satu sel punya 4 sudut → tile dipilih dari situ.

    mask = NW*1 + NE*2 + SE*4 + SW*8      (bit 0 = terrain pertama di nama pair, bit 1 = terrain kedua)

Contoh `grass_water`, sudut [NW,NE,SE,SW] = [grass,grass,water,water] → mask 12 → `edge_grassN`.

## Penting
- N/E/S/W di nama tile = arah **grid** (y-1, x+1, y+1, x-1), BUKAN arah layar iso.
- Posisi layar: `sx = (x - y) * 64`, `sy = (x + y) * 32`.
- Pair tersedia: grass_dirt, grass_sand, grass_water, grass_cobble, dirt_sand, sand_water.
  Tidak ada: dirt↔water, cobble↔dirt/sand/water, dan cobble_brown (cobble_01, coklat) belum punya transisi. Satu sel hanya boleh berisi 1 terrain atau 2 terrain yang punya pair
  (rantai yang valid: air → pasir → tanah/rumput; cobble hanya boleh nempel ke rumput).
- Mask 5 & 10 (diagonal/saddle) tidak punya tile → fallback ke terrain prioritas (grass > dirt > sand > water) dan dicatat di `Autotiler.problems`.
- Kalau melukis per SEL, pakai `from_cells()` (dual-grid, gambar digeser grid -0.5,-0.5).

## File
- `autotile_rules.json` – tabel mask → tile untuk semua pair (dibaca engine)
- `autotile.py` – logika pemilih tile (+ `python3 autotile.py demo`)
- `previews/mask_chart_<pair>.png` – chart 16 mask per pair (cek visual)
- `previews/autotile_demo.png` – contoh peta hasil autotile
- `tools/build_rules.py`, `tools/mask_chart.py` – regenerasi JSON & chart kalau tile diganti
