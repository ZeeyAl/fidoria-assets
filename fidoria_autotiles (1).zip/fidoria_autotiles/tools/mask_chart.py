#!/usr/bin/env python3
"""Chart 16 mask per pair: tile + terrain di tiap sudut (NW/NE/SE/SW) + nama. Output: previews/mask_chart_<pair>.png"""
import json, os
from PIL import Image, ImageDraw
R = json.load(open("autotile_rules.json"))
COL = {"grass": (90, 170, 40), "dirt": (140, 85, 45), "sand": (235, 190, 110), "water": (20, 130, 235), "cobble": (130, 125, 130)}
# sudut grid -> titik di diamond layar (NW=atas, NE=kanan, SE=bawah, SW=kiri)
POS = {"NW": (64, 2), "NE": (126, 32), "SE": (64, 62), "SW": (2, 32)}
CW, CH = 250, 190
for pair, P in R["pairs"].items():
    cv = Image.new("RGB", (CW * 4, CH * 4 + 36), (30, 30, 38)); d = ImageDraw.Draw(cv)
    d.text((10, 10), f"{pair}   bit0 = {P['T1']}   bit1 = {P['T2']}   mask = NW*1 + NE*2 + SE*4 + SW*8", fill=(255, 255, 255))
    for m in range(16):
        ox, oy = (m % 4) * CW, (m // 4) * CH + 36
        e = P["masks"].get(str(m))
        d.rectangle([ox + 4, oy + 4, ox + CW - 4, oy + CH - 4], outline=(70, 70, 85))
        d.text((ox + 12, oy + 10), f"mask {m:2d}  = 0b{m:04b}", fill=(255, 255, 255))
        if e is None:
            d.text((ox + 12, oy + 80), "SADDLE - tidak ada tile\n(fallback: terrain prioritas)", fill=(255, 120, 120)); continue
        tp = e["tile"] or R["base"][e["corners"]["NW"]][0]
        t = Image.open(tp).convert("RGBA"); tx, ty = ox + 60, oy + 60
        cv.paste(t, (tx, ty), t)
        for c, (px, py) in POS.items():
            col = COL[e["corners"][c]]
            lx, ly = tx + px, ty + py
            d.ellipse([lx - 6, ly - 6, lx + 6, ly + 6], fill=col, outline=(255, 255, 255))
            off = {"NW": (-10, -24), "NE": (10, -6), "SE": (-8, 10), "SW": (-34, -6)}[c]
            d.text((lx + off[0], ly + off[1]), c, fill=(220, 220, 220))
        d.text((ox + 12, oy + CH - 26), e["name"], fill=(160, 220, 255))
    cv.save(f"previews/mask_chart_{pair}.png")
print("ok")
