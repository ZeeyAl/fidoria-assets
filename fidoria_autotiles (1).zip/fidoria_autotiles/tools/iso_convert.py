#!/usr/bin/env python3
"""
iso_convert.py - ubah tekstur datar seamless (top-down) jadi tile isometric 2:1.

Pemakaian:
  python3 iso_convert.py INPUT [INPUT ...] [-o OUTDIR] [-w 128] [--smooth]

  INPUT   : file gambar atau folder berisi gambar (png/jpg/webp)
  -o      : folder output (default: iso_out)
  -w      : lebar diamond dalam pixel (default 128 -> tinggi 64)
  --smooth: pakai bilinear (untuk non-pixel-art). Default nearest (pixel crisp)
  --no-checks: skip bikin preview seamless

Output per input:
  OUTDIR/<nama>.png            tile diamond RGBA, ukuran persis W x W/2
  OUTDIR/checks/<nama>_flat.png    tekstur asli dijejer 3x3 (cek seamless)
  OUTDIR/checks/<nama>_iso.png     tile iso dijejer 6x6 (cek nyambung di grid)
"""
import argparse, os, sys
import numpy as np
from PIL import Image

EXT = (".png", ".jpg", ".jpeg", ".webp")

def collect(paths):
    out = []
    for p in paths:
        if os.path.isdir(p):
            for f in sorted(os.listdir(p)):
                if f.lower().endswith(EXT):
                    out.append(os.path.join(p, f))
        elif p.lower().endswith(EXT):
            out.append(p)
    return out

def to_iso(img, W, smooth=False):
    H = W // 2
    img = img.convert("RGBA")
    # crop ke persegi tengah
    s = min(img.size)
    l, t = (img.width - s) // 2, (img.height - s) // 2
    img = img.crop((l, t, l + s, t + s))
    # prescale supaya pixel density mirip output (hindari aliasing)
    side = max(8, round(W / 2 ** 0.5))
    if not smooth:
        img = img.resize((side, side), Image.BOX)
    src = np.asarray(img).astype(np.float32)
    n = src.shape[0]

    ys, xs = np.mgrid[0:H, 0:W]
    dx = (xs + 0.5) / W - 0.5
    dy = (ys + 0.5) / H - 0.5
    mask = (np.abs(dx) + np.abs(dy)) <= 0.5 + 1e-6
    u = np.clip(dx + dy + 0.5, 0, 1 - 1e-6) * n
    v = np.clip(dy - dx + 0.5, 0, 1 - 1e-6) * n

    if smooth:
        x0 = np.floor(u - 0.5).astype(int); y0 = np.floor(v - 0.5).astype(int)
        fx = (u - 0.5 - x0)[..., None]; fy = (v - 0.5 - y0)[..., None]
        g = lambda yy, xx: src[np.clip(yy, 0, n - 1), np.clip(xx, 0, n - 1)]
        out = (g(y0, x0) * (1 - fx) * (1 - fy) + g(y0, x0 + 1) * fx * (1 - fy)
               + g(y0 + 1, x0) * (1 - fx) * fy + g(y0 + 1, x0 + 1) * fx * fy)
    else:
        out = src[v.astype(int), u.astype(int)]
    out = out.copy()
    out[..., 3] = np.where(mask, 255, 0)
    return Image.fromarray(out.astype(np.uint8), "RGBA")

def flat_check(img, size=256):
    img = img.convert("RGB").resize((size, size), Image.NEAREST)
    c = Image.new("RGB", (size * 3, size * 3))
    for i in range(3):
        for j in range(3):
            c.paste(img, (i * size, j * size))
    return c

def iso_grid(tile, n=6):
    W, H = tile.size
    canvas = Image.new("RGBA", (n * W, n * H), (40, 40, 48, 255))
    ox = (n - 1) * W // 2
    for i in range(n):
        for j in range(n):
            x = ox + (i - j) * W // 2
            y = (i + j) * H // 2
            canvas.alpha_composite(tile, (x, y))
    return canvas

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("inputs", nargs="+")
    ap.add_argument("-o", "--out", default="iso_out")
    ap.add_argument("-w", "--width", type=int, default=128)
    ap.add_argument("--smooth", action="store_true")
    ap.add_argument("--no-checks", action="store_true")
    a = ap.parse_args()
    if a.width % 2:
        sys.exit("width harus genap")
    files = collect(a.inputs)
    if not files:
        sys.exit("nggak nemu gambar")
    os.makedirs(os.path.join(a.out, "checks"), exist_ok=True)
    for f in files:
        name = os.path.splitext(os.path.basename(f))[0]
        src = Image.open(f)
        tile = to_iso(src, a.width, a.smooth)
        tile.save(os.path.join(a.out, name + ".png"))
        if not a.no_checks:
            flat_check(src).save(os.path.join(a.out, "checks", name + "_flat.png"))
            iso_grid(tile).save(os.path.join(a.out, "checks", name + "_iso.png"))
        print("ok", name, tile.size)

if __name__ == "__main__":
    main()
