#!/usr/bin/env python3
"""Bikin autotile_rules.json dari nama file transisi.
Jalankan dari root paket:  python3 tools/build_rules.py
"""
import json, os, re

# urutan sudut + bobot bit (SATU-SATUNYA aturan yang perlu dihafal)
CORNERS = ["NW", "NE", "SE", "SW"]
BIT = {"NW": 1, "NE": 2, "SE": 4, "SW": 8}
SIDES = {"N": ["NW", "NE"], "E": ["NE", "SE"], "S": ["SE", "SW"], "W": ["SW", "NW"]}
# prioritas terrain: kiri = T1 (bit 0), kanan = T2 (bit 1) pada nama pair
PAIRS = ["grass_dirt", "grass_sand", "grass_water", "grass_cobble", "dirt_sand", "sand_water"]

rules = {
    "version": 2,
    "tile_size": {"w": 128, "h": 64, "shape": "diamond isometric 2:1"},
    "model": "corner-wang: tile dipilih dari terrain di 4 SUDUT sel (vertex), bukan dari 8 tetangga",
    "corner_order": CORNERS,
    "corner_bits": BIT,
    "bit_meaning": "bit=0 -> terrain T1 (kiri di nama pair), bit=1 -> terrain T2 (kanan)",
    "mask_formula": "mask = NW*1 + NE*2 + SE*4 + SW*8",
    "grid_to_screen": "sx = (x - y) * w/2 ; sy = (x + y) * h/2  (x ke SE-layar, y ke SW-layar)",
    "compass_note": "N/E/S/W pada nama tile = arah GRID (y-1, x+1, y+1, x-1), bukan arah layar",
    "saddle_masks": [5, 10],
    "saddle_note": "mask 5 & 10 (T2 hanya di sudut diagonal) tidak punya tile; lihat fallback di autotile.py",
    "terrain_priority": ["grass", "cobble", "dirt", "sand", "water"],
    "base": {},
    "pairs": {},
}
for f in sorted(os.listdir("base")):
    m = re.match(r"([a-z]+)_\d+\.png", f)
    name = m.group(1)
    if f == "cobble_01.png":      # cobble_01 warnanya coklat, beda material dari cobble abu-abu (cobble_02)
        name = "cobble_brown"     # belum punya transisi, jadi tidak dipakai otomatis
    rules["base"].setdefault(name, []).append("base/" + f)

for pair in PAIRS:
    t1, t2 = pair.split("_")
    table = {}
    for f in sorted(os.listdir(f"transitions/{pair}")):
        m = re.match(rf"{pair}_(edge|corner)_([a-z]+?)(NW|NE|SE|SW|N|E|S|W)\.png$", f)
        kind, ter, d = m.groups()
        other = t2 if ter == t1 else t1
        if kind == "edge":
            cs = {c: (ter if c in SIDES[d] else other) for c in CORNERS}
        else:
            cs = {c: (ter if c == d else other) for c in CORNERS}
        mask = sum(BIT[c] for c in CORNERS if cs[c] == t2)
        assert mask not in table, (pair, mask, f)
        table[mask] = {"mask": mask, "name": f[len(pair) + 1:-4], "tile": f"transitions/{pair}/{f}", "corners": cs}
    table[0] = {"mask": 0, "name": f"pure_{t1}", "tile": None, "corners": {c: t1 for c in CORNERS}}
    table[15] = {"mask": 15, "name": f"pure_{t2}", "tile": None, "corners": {c: t2 for c in CORNERS}}
    missing = [m for m in range(16) if m not in table]
    assert missing == [5, 10], (pair, missing)
    rules["pairs"][pair] = {"T1": t1, "T2": t2, "masks": {str(k): table[k] for k in sorted(table)}}

json.dump(rules, open("autotile_rules.json", "w"), indent=2)
print("ok", {p: len(v["masks"]) for p, v in rules["pairs"].items()})
